# Dacia Smart AI Assistant — Manual v3.2

**ESP32 + ELM327 Bluetooth + Google Gemini + I2S MAX98357A**

---

## ¿Qué es esto?

Un asistente de voz para el coche que lee los sensores del motor en tiempo real, los analiza con inteligencia artificial (Google Gemini) y te habla en español a través de un altavoz. Se activa con un botón físico.

**Flujo de funcionamiento:**

```
[Botón] → ESP32 → ELM327 (Bluetooth) → Puerto OBD2 del coche
                                              ↓
                                    RPM, Temp, Vel, DTCs...
                                              ↓
                              Google Gemini (análisis IA)
                                              ↓
                              Google Cloud TTS (voz en español)
                                              ↓
                                  MAX98357A → Altavoz
```

---

## Lista de materiales

| Componente | Descripción | Precio aprox. |
|---|---|---|
| ESP32 Dev Module | Cualquier placa ESP32 de 38 pines | ~5 € |
| ELM327 Bluetooth | Escáner OBD2 BT (evitar Wi-Fi) | ~5–10 € |
| MAX98357A | Amplificador I2S + altavoz 3W | ~3–6 € |
| Altavoz 4–8 Ω | Cualquier altavoz pequeño | ~2–4 € |
| Botón pulsador | Opcional (se puede usar el BOOT del ESP32) | ~0.50 € |
| Cable USB | Para programar el ESP32 | — |

> **Recomendado:** ESP32-WROVER (con PSRAM integrada). El código detecta la PSRAM automáticamente y la usa para el buffer de audio, mejorando la estabilidad.

---

## Conexiones hardware

### MAX98357A → ESP32

| Pin MAX98357A | GPIO ESP32 | Descripción |
|---|---|---|
| BCLK | GPIO 25 | Bit Clock |
| LRC | GPIO 26 | Word Select (L/R Clock) |
| DIN | GPIO 22 | Datos de audio |
| VIN | 3.3V o 5V | Alimentación |
| GND | GND | Tierra |
| SD (opcional) | — | Dejar al aire = canal izquierdo |

### Botón de diagnóstico

| Pin | GPIO ESP32 | Descripción |
|---|---|---|
| Un lado del botón | GPIO 0 | BOOT button integrado |
| Otro lado | GND | — |

> El GPIO 0 ya tiene resistencia pull-up interna. No necesitas resistencia externa.

### ELM327

El ELM327 se conecta **de forma inalámbrica por Bluetooth**. Simplemente enchúfalo al puerto OBD2 del coche (debajo del volante, lado izquierdo) y enciende el motor.

---

## Configuración paso a paso

### 1. Instalar Arduino IDE y librerías

1. Descarga [Arduino IDE 2.x](https://www.arduino.cc/en/software)
2. Ve a **File → Preferences** y añade esta URL en "Additional boards manager URLs":
   ```
   https://raw.githubusercontent.com/espressif/arduino-esp32/gh-pages/package_esp32_index.json
   ```
3. Ve a **Tools → Board → Boards Manager**, busca `esp32` e instala el paquete de **Espressif**
4. Instala las librerías en **Tools → Manage Libraries**:
   - `ArduinoJson` por Benoit Blanchon
   - `ESP8266Audio` por earlephilhower

### 2. Configurar el proyecto

Abre el archivo `DaciaSmartAI_v3.2.ino` y edita estas líneas al principio:

```cpp
const char* WIFI_SSID      = "TU_WIFI_SSID";        // ← Nombre de tu red WiFi
const char* WIFI_PASS      = "TU_WIFI_PASSWORD";     // ← Contraseña WiFi
const char* GEMINI_KEY     = "TU_GEMINI_API_KEY";    // ← Ver paso 3
const char* GOOGLE_TTS_KEY = "TU_GOOGLE_CLOUD_TTS_KEY"; // ← Ver paso 4
const char* ELM327_NAME    = "OBDII";                // ← Nombre BT de tu ELM327
const char* ELM327_PIN     = "1234";                 // ← PIN del ELM327
```

### 3. Obtener API Key de Google Gemini (gratis)

1. Ve a [aistudio.google.com](https://aistudio.google.com)
2. Haz clic en **Get API Key → Create API Key**
3. Copia la clave y pégala en `GEMINI_KEY`

> **Límites gratuitos:** 15 peticiones/minuto, 1.500 peticiones/día. Más que suficiente.

### 4. Obtener API Key de Google Cloud TTS (gratis)

1. Ve a [console.cloud.google.com](https://console.cloud.google.com)
2. Crea un proyecto nuevo (o usa uno existente)
3. Ve a **APIs y servicios → Biblioteca**
4. Busca **Cloud Text-to-Speech API** y actívala
5. Ve a **APIs y servicios → Credenciales → + Crear credencial → Clave de API**
6. Copia la clave y pégala en `GOOGLE_TTS_KEY`

> **Límites gratuitos:** 1.000.000 caracteres/mes. Para este uso: prácticamente ilimitado.

### 5. Configurar Arduino IDE

| Ajuste | Valor |
|---|---|
| Board | ESP32 Dev Module |
| Partition Scheme | Default 4MB with spiffs |
| CPU Frequency | 240 MHz |
| Upload Speed | 921600 |
| Port | El puerto COM/ttyUSB del ESP32 |

### 6. Flashear

1. Conecta el ESP32 por USB
2. Selecciona el puerto en **Tools → Port**
3. Haz clic en **Upload** (flecha →)
4. Si el upload no empieza, mantén pulsado el botón BOOT del ESP32 hasta que aparezca "Connecting..."

---

## Uso

### Botón físico (GPIO 0)

Pulsa el botón BOOT del ESP32 una vez. El sistema:
1. Dice "Iniciando diagnóstico. Un momento."
2. Lee todos los sensores del coche
3. Si hay algo anómalo, consulta a Gemini
4. Reproduce el resultado por voz

### Serial Monitor (para desarrollo)

Conecta el ESP32 por USB, abre **Tools → Serial Monitor** a **115200 baud** y usa estos comandos:

| Comando | Acción |
|---|---|
| `diag` | Ejecutar diagnóstico completo |
| `rpm` | Leer RPM actuales |
| `temp` | Temperatura del refrigerante (°C) |
| `speed` | Velocidad actual (km/h) |
| `fuel` | Nivel de combustible (%) |
| `dtc` | Códigos de error OBD2 |
| `vol+` | Subir volumen (paso 0.1) |
| `vol-` | Bajar volumen |
| `say hola` | Reproducir texto por voz |
| `status` | Estado de WiFi, BT y memoria |
| `cache` | Listar archivos en LittleFS |
| `clearcache` | Borrar caché de respuestas Gemini |
| `ATI` | Versión del ELM327 (u otro comando AT) |

---

## Comportamiento según el estado del motor

| Situación | Respuesta del sistema |
|---|---|
| Todo normal (RPM OK, temp 60–100°C, sin DTCs) | "Motor en buen estado. Sin códigos de error." |
| Temperatura > 105°C | **Alerta inmediata:** "Para el coche inmediatamente." |
| Combustible < 10% | "Aviso: combustible muy bajo, X por ciento." |
| Código de error detectado | Gemini analiza y explica en lenguaje simple |
| Sin WiFi | Diagnóstico básico local sin IA |
| Sin ELM327 | Sistema arranca pero no lee datos del coche |

---

## Arquitectura técnica

### Distribución de núcleos (FreeRTOS)

```
Núcleo 0 (prioridad 2) — obdTask
  └─ Lectura OBD2 por Bluetooth
  └─ Detección del botón (GPIO 0)
  └─ Envío de comandos a la cola

Núcleo 1 (prioridad 1) — audioTask
  └─ Reproducción de audio I2S
  └─ Llamadas a Gemini y Cloud TTS
  └─ Comandos Serial Monitor

loop() — Monitorización
  └─ Reconexión WiFi cada 30s
  └─ Reconexión Bluetooth cada 15s
```

### Comunicación entre tareas

```
[Botón / Serial] → cmdQueue (uint8_t) → obdTask
obdTask          → diagQueue (DiagResult) → audioTask
```

### Caché LittleFS

Las respuestas de Gemini se guardan en LittleFS con una clave basada en los datos del vehículo. Si se repite la misma situación (mismo contexto), no se hace llamada a la API.

---

## Solución de problemas

### El ESP32 no conecta al ELM327

- Verifica que `ELM327_NAME` coincide exactamente con el nombre Bluetooth del escáner
- El ELM327 debe estar enchufado al OBD2 y el coche en posición "ACC" o motor en marcha
- Prueba a cambiar `ELM327_PIN` a `"0000"` (algunos modelos usan ese PIN)
- Algunos clones baratos necesitan `ATSP1` en lugar de `ATSP0` (protocolo fijo)

### No hay audio / no suena nada

1. Verifica las conexiones GPIO 25, 26 y 22 del MAX98357A
2. Abre Serial Monitor y escribe `say hola` — si ves `[VOZ] hola` pero no suena, es hardware
3. Verifica que `GOOGLE_TTS_KEY` está configurada correctamente
4. Escribe `status` para confirmar que WiFi está conectado

### El ESP32 se reinicia en bucle

- Abre Serial Monitor y observa el mensaje de error antes del reinicio
- Si el heap libre es < 20.000 bytes, el archivo MP3 es demasiado grande para la RAM
- Considera usar una placa ESP32-WROVER (con PSRAM)

### Los sensores devuelven -1

- El coche debe estar en marcha (o al menos en ACC con motor arrancado)
- No todos los coches soportan todos los PIDs. El combustible (012F) no está disponible en algunos modelos Dacia
- Escribe el PID directamente: p.ej. `010C` para RPM

### Gemini devuelve error HTTP 400 o 429

- 400: verifica que `GEMINI_KEY` es correcta y que la API está activada
- 429: has superado el límite de peticiones por minuto (15 rpm gratuito). Espera 60 segundos.

---

## Personalización

### Cambiar la voz

En `speakCloudTTS()`, modifica el campo `name`:

| Voz | Descripción |
|---|---|
| `es-ES-Standard-A` | Mujer, español de España (por defecto) |
| `es-ES-Standard-B` | Hombre, español de España |
| `es-US-Standard-A` | Mujer, español latinoamericano |
| `es-ES-Neural2-A` | Mujer, más natural (mayor calidad, mismo precio) |

### Cambiar el idioma de Gemini

En `askGemini()`, modifica el prompt:
```cpp
"Eres un mecánico experto. Responde SOLO en árabe..."
```

### Añadir MP3 pregrabados (modo offline)

Si no tienes acceso a internet, puedes subir MP3 pregrabados a LittleFS.
El nombre del archivo debe empezar por `/audio_` seguido de los primeros 10 caracteres alfanuméricos del texto.

Ejemplo para "Motor en buen estado":
- Texto: `"Motor en buen estado"`
- Hash: `Motorenbu`
- Nombre de archivo: `/audio_Motorenbu.mp3`

Usa la herramienta **LittleFS Data Upload** de Arduino IDE para subir los archivos.

---

## Changelog

### v3.2 (actual)
- **[BUG A]** `playMP3FromLittleFS` no reproducía audio — corregido con loop MP3 real
- **[BUG B]** `StaticJsonDocument<4096>` insuficiente para base64 de audio — corregido extrayendo `audioContent` directamente del JSON crudo
- **[BUG C]** Semáforos creados después de usarlos → crash en bucle — corregido moviéndolos al inicio de `setup()`
- **[BUG D]** `aiResponse[256]` truncaba respuestas de Gemini — ampliado a 512 bytes
- Código limpio: eliminado código muerto (`AudioFileSourceHTTPStream` placeholder, funciones sin usar)

### v3.0
- FreeRTOS dual-core (BT en núcleo 0, WiFi/audio en núcleo 1)
- Google Cloud TTS oficial (reemplaza translate.google.com no oficial)
- LittleFS en lugar de SPIFFS (deprecado en ESP32 Core v2+)
- Parser OBD2 robusto con reintentos, validación y soporte para clones
- Buffer audio 32KB (sin cortes)

### v2.0
- Integración Google Gemini API
- Caché de respuestas en SPIFFS

### v1.0
- Prototipo inicial con TTS no oficial

---

*Manual generado para DaciaSmartAI v3.2 — ESP32 + ELM327 + Gemini + MAX98357A*

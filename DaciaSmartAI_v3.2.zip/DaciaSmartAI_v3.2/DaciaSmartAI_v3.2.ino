/*
 * ════════════════════════════════════════════════════════════════
 *  DACIA SMART AI ASSISTANT — v3.2
 *  ESP32 + ELM327 Bluetooth + Google Gemini + I2S MAX98357A
 * ════════════════════════════════════════════════════════════════
 *
 *  DESCRIPCIÓN:
 *  Asistente de voz inteligente para diagnóstico OBD2 en tiempo real.
 *  Lee sensores del motor vía Bluetooth (ELM327), analiza los datos
 *  con Google Gemini y reproduce el resultado por voz (Google Cloud TTS)
 *  a través de un amplificador I2S MAX98357A.
 *
 *  LIBRERÍAS NECESARIAS (Arduino IDE → Library Manager):
 *  ┌────────────────────────────────────────────────────────────┐
 *  │  ArduinoJson       — Benoit Blanchon                       │
 *  │  ESP8266Audio      — earlephilhower (buscar "ESP8266Audio") │
 *  │  LittleFS          — incluida en ESP32 Core v2+            │
 *  └────────────────────────────────────────────────────────────┘
 *
 *  CONFIGURACIÓN ARDUINO IDE:
 *  ┌────────────────────────────────────────────────────────────┐
 *  │  Board            : ESP32 Dev Module                       │
 *  │  Partition Scheme : Default 4MB with spiffs                │
 *  │  CPU Frequency    : 240 MHz (dual core requerido)          │
 *  │  Upload Speed     : 921600                                 │
 *  └────────────────────────────────────────────────────────────┘
 *
 *  CONEXIONES HARDWARE:
 *  ┌──────────────┬──────────┬─────────────────────────────────┐
 *  │ MAX98357A    │ GPIO 25  │ BCLK  — Bit Clock               │
 *  │              │ GPIO 26  │ LRC   — Word Select             │
 *  │              │ GPIO 22  │ DIN   — Data In                 │
 *  │              │ 3.3V/5V  │ VIN   — Alimentación            │
 *  │              │ GND      │ GND   — Tierra                  │
 *  ├──────────────┼──────────┼─────────────────────────────────┤
 *  │ Botón diag   │ GPIO 0   │ BOOT button (integrado en ESP32) │
 *  └──────────────┴──────────┴─────────────────────────────────┘
 *
 *  COMANDOS SERIAL MONITOR (115200 baud):
 *  ┌─────────────┬───────────────────────────────────────────┐
 *  │ diag        │ Lanzar diagnóstico completo               │
 *  │ rpm         │ Leer RPM actuales                         │
 *  │ temp        │ Leer temperatura refrigerante             │
 *  │ speed       │ Leer velocidad actual                     │
 *  │ fuel        │ Leer nivel de combustible                 │
 *  │ dtc         │ Leer códigos de error (DTCs)              │
 *  │ vol+ / vol- │ Subir / bajar volumen (paso 0.1)          │
 *  │ say <texto> │ Reproducir texto por voz                  │
 *  │ status      │ Estado WiFi, BT y memoria libre           │
 *  │ cache       │ Listar archivos en LittleFS               │
 *  │ clearcache  │ Borrar caché de respuestas Gemini         │
 *  │ <AT cmd>    │ Enviar cualquier comando AT al ELM327     │
 *  └─────────────┴───────────────────────────────────────────┘
 *
 *  HISTORIAL DE VERSIONES:
 *  v1.0 — Prototipo inicial (SPIFFS + TTS no oficial)
 *  v2.0 — Integración Gemini API
 *  v3.0 — FreeRTOS dual-core, LittleFS, parser OBD2 robusto,
 *          Google Cloud TTS oficial, buffer audio 32KB
 *  v3.2 — Corrección de 4 bugs críticos:
 *         [A] playMP3FromLittleFS no reproducía audio (código muerto)
 *         [B] Buffer JSON 4KB insuficiente para base64 del MP3 (~100KB)
 *         [C] Semáforos creados después de usarlos → crash en bucle
 *         [D] aiResponse[256] truncaba respuestas de Gemini
 * ════════════════════════════════════════════════════════════════
 */

// ─── INCLUDES ─────────────────────────────────────────────────
#include <Arduino.h>
#include <BluetoothSerial.h>
#include <WiFi.h>
#include <HTTPClient.h>
#include <WiFiClientSecure.h>
#include <ArduinoJson.h>
#include <LittleFS.h>

// Audio I2S (librería ESP8266Audio de earlephilhower)
#include "AudioGeneratorMP3.h"
#include "AudioFileSourcePROGMEM.h"
#include "AudioFileSourceBuffer.h"
#include "AudioOutputI2S.h"

// ─── CREDENCIALES Y CONFIGURACIÓN ─────────────────────────────
// ⚠️  EDITA ESTAS LÍNEAS ANTES DE FLASHEAR
const char* WIFI_SSID      = "TU_WIFI_SSID";
const char* WIFI_PASS      = "TU_WIFI_PASSWORD";
const char* GEMINI_KEY     = "TU_GEMINI_API_KEY";
const char* GOOGLE_TTS_KEY = "TU_GOOGLE_CLOUD_TTS_KEY";

// Bluetooth OBD2
const char* ELM327_NAME    = "OBDII";   // Nombre BT del escáner ELM327
const char* ELM327_PIN     = "1234";    // PIN del escáner (casi siempre 1234)

// Hardware
const int BUTTON_PIN = 0;    // GPIO0 = botón BOOT integrado en ESP32

// ─── PINES I2S ────────────────────────────────────────────────
#define I2S_BCLK  25
#define I2S_LRC   26
#define I2S_DOUT  22

// ─── FREERTOS: COLAS, SEMÁFOROS Y HANDLES ─────────────────────
QueueHandle_t     diagQueue;      // DiagResult: OBD task → audio task
QueueHandle_t     cmdQueue;       // uint8_t: botón/serial → OBD task
SemaphoreHandle_t btMutex;        // Acceso exclusivo al Bluetooth
SemaphoreHandle_t wifiMutex;      // Acceso exclusivo al WiFi/HTTP

TaskHandle_t obdTaskHandle   = NULL;
TaskHandle_t audioTaskHandle = NULL;

// ─── OBJETOS GLOBALES ─────────────────────────────────────────
BluetoothSerial    BT;
AudioGeneratorMP3* mp3  = nullptr;
AudioFileSourceBuffer*    buff = nullptr;
AudioOutputI2S*    out  = nullptr;

volatile bool btConnected   = false;
volatile bool wifiConnected = false;
float         currentGain   = 0.8f;

// ─── ESTRUCTURA DE DIAGNÓSTICO ────────────────────────────────
struct DiagResult {
  int  rpm;
  int  speed;
  int  temp;
  int  load;
  int  fuel;
  char dtcs[64];
  char aiResponse[512];   // 512 bytes: suficiente para respuestas Gemini (~500 chars)
  bool hasError;
};

// ══════════════════════════════════════════════════════════════
//  CACHÉ LITTLEFS
// ══════════════════════════════════════════════════════════════

bool cacheExists(const String& key) {
  return LittleFS.exists("/c_" + key.substring(0, 20) + ".txt");
}

String cacheRead(const String& key) {
  File f = LittleFS.open("/c_" + key.substring(0, 20) + ".txt", "r");
  if (!f) return "";
  String s = f.readString();
  f.close();
  return s;
}

void cacheWrite(const String& key, const String& value) {
  String path = "/c_" + key.substring(0, 20) + ".txt";
  File f = LittleFS.open(path, "w");
  if (!f) return;
  f.print(value);
  f.close();
  Serial.println("[CACHE] Guardado: " + path);
}

// ══════════════════════════════════════════════════════════════
//  OBD2 — COMUNICACIÓN Y PARSING
// ══════════════════════════════════════════════════════════════

bool isOBDResponseValid(const String& r) {
  if (r.length() < 4)           return false;
  if (r.indexOf("ERROR")   >= 0) return false;
  if (r.indexOf("UNABLE")  >= 0) return false;
  if (r.indexOf("STOPPED") >= 0) return false;
  if (r.indexOf("SEARCHING")>= 0)return false;
  if (r.indexOf("?")       >= 0) return false;
  if (r.indexOf("NO DATA") >= 0) return false;
  if (r.indexOf("NODATA")  >= 0) return false;
  return true;
}

// Enviar comando OBD2 con reintentos y timeout estricto
String sendOBD(const String& cmd, int waitMs = 600, int retries = 3) {
  if (xSemaphoreTake(btMutex, pdMS_TO_TICKS(1000)) != pdTRUE) {
    return "ERROR_MUTEX";
  }

  String response = "";
  for (int attempt = 0; attempt < retries; attempt++) {
    while (BT.available()) BT.read(); // Limpiar buffer
    BT.println(cmd);
    response = "";
    unsigned long start = millis();

    while (millis() - start < (unsigned long)waitMs) {
      while (BT.available()) {
        char c = BT.read();
        if (c != '\r' && c != '>' && c != '\0') response += c;
      }
      if (response.endsWith(">")) break;
      vTaskDelay(pdMS_TO_TICKS(5));
    }

    response.trim();
    response.replace("\n", "");
    if (isOBDResponseValid(response)) break;

    Serial.printf("[OBD] Reintento %d/%d: %s\n", attempt + 1, retries, cmd.c_str());
    vTaskDelay(pdMS_TO_TICKS(200));
  }

  xSemaphoreGive(btMutex);
  return response;
}

bool initELM327() {
  Serial.println("[OBD] Inicializando ELM327...");
  sendOBD("ATZ",    1500);  vTaskDelay(pdMS_TO_TICKS(500)); // Reset
  sendOBD("ATE0",   400);   // Echo OFF
  sendOBD("ATL0",   300);   // Linefeed OFF
  sendOBD("ATS0",   300);   // Spaces OFF
  sendOBD("ATH0",   300);   // Headers OFF
  sendOBD("ATAT1",  300);   // Adaptive timing (mejora compatibilidad con clones)
  sendOBD("ATST32", 300);   // Timeout 320ms

  String proto = sendOBD("ATSP0", 1200);
  Serial.println("[OBD] Protocolo auto: " + proto);

  String test = sendOBD("0100", 800);
  if (!isOBDResponseValid(test)) {
    Serial.println("[OBD] ADVERTENCIA: respuesta inesperada a 0100. Posible clon.");
    return false;
  }
  Serial.println("[OBD] ELM327 OK");
  return true;
}

// Extraer valor numérico de una respuesta OBD2 en hex
int parseHexPID(const String& raw, int byteOffset, int byteLen) {
  String r = raw;
  r.replace(" ", "");
  if (!isOBDResponseValid(r)) return -1;

  int start = 4 + (byteOffset * 2);
  if (start + (byteLen * 2) > (int)r.length()) return -1;

  String hex = r.substring(start, start + byteLen * 2);
  for (char c : hex) {
    if (!isHexadecimalDigit(c)) return -1;
  }
  return (int)strtol(hex.c_str(), NULL, 16);
}

int readRPM() {
  int raw = parseHexPID(sendOBD("010C"), 0, 2);
  return (raw >= 0) ? raw / 4 : -1;
}

int readSpeed() {
  return parseHexPID(sendOBD("010D"), 0, 1);
}

int readCoolantTemp() {
  int raw = parseHexPID(sendOBD("0105"), 0, 1);
  return (raw >= 0) ? raw - 40 : -1;
}

int readEngineLoad() {
  int raw = parseHexPID(sendOBD("0104"), 0, 1);
  return (raw >= 0) ? (raw * 100) / 255 : -1;
}

int readFuelLevel() {
  int raw = parseHexPID(sendOBD("012F"), 0, 1);
  return (raw >= 0) ? (raw * 100) / 255 : -1;
}

String readDTCs() {
  String r = sendOBD("03", 1500, 2);
  return isOBDResponseValid(r) ? r : "SIN_CODIGOS";
}

String parseDTCs(const String& raw) {
  if (raw == "SIN_CODIGOS") return "Ninguno";
  String r = raw;
  r.replace(" ", "");
  String result = "";
  for (int i = 4; i + 4 <= (int)r.length(); i += 4) {
    String chunk = r.substring(i, i + 4);
    if (chunk == "0000") continue;
    bool validHex = true;
    for (char c : chunk) if (!isHexadecimalDigit(c)) { validHex = false; break; }
    if (!validHex) continue;
    int val = (int)strtol(chunk.c_str(), NULL, 16);
    if (val == 0) continue;
    char type = "PCBU"[(val >> 14) & 0x03];
    char code[8];
    snprintf(code, sizeof(code), "%c%04X", type, val & 0x3FFF);
    if (result != "") result += ", ";
    result += String(code);
  }
  return result.length() > 0 ? result : "Ninguno";
}

// ══════════════════════════════════════════════════════════════
//  AUDIO I2S
// ══════════════════════════════════════════════════════════════

void initAudio() {
  out = new AudioOutputI2S();
  out->SetPinout(I2S_BCLK, I2S_LRC, I2S_DOUT);
  out->SetGain(currentGain);
  out->SetRate(22050);
  Serial.println("[AUDIO] I2S inicializado");
}

void stopAudio() {
  if (mp3 && mp3->isRunning()) mp3->stop();
  if (buff) { delete buff; buff = nullptr; }
  if (mp3)  { delete mp3;  mp3  = nullptr; }
}

// Reproducir un archivo MP3 guardado en LittleFS
// Carga el archivo en RAM (PSRAM si disponible) y lo decodifica con MP3.
void playMP3FromLittleFS(const char* path) {
  stopAudio();

  if (!LittleFS.exists(path)) {
    Serial.println("[AUDIO] Archivo no encontrado: " + String(path));
    return;
  }

  // Obtener tamaño del archivo
  size_t fileSize = 0;
  {
    File f = LittleFS.open(path, "r");
    if (!f) { Serial.println("[AUDIO] Error al abrir archivo"); return; }
    fileSize = f.size();
    f.close();
  }

  if (fileSize == 0) {
    Serial.println("[AUDIO] Archivo vacío");
    return;
  }

  // Reservar memoria: PSRAM primero (ESP32-WROVER), heap si no hay PSRAM
  uint8_t* audioData = nullptr;
  if (psramFound()) {
    audioData = (uint8_t*)ps_malloc(fileSize);
    if (audioData) Serial.printf("[AUDIO] PSRAM: %d bytes\n", fileSize);
  }
  if (!audioData) {
    audioData = (uint8_t*)malloc(fileSize);
    if (audioData) Serial.printf("[AUDIO] Heap: %d bytes\n", fileSize);
  }
  if (!audioData) {
    Serial.printf("[AUDIO] Sin memoria para %d bytes (heap libre: %d)\n",
                  fileSize, ESP.getFreeHeap());
    return;
  }

  // Leer MP3 completo en buffer
  File f = LittleFS.open(path, "r");
  size_t bytesRead = f.read(audioData, fileSize);
  f.close();

  if (bytesRead != fileSize) {
    Serial.printf("[AUDIO] Lectura incompleta: %d/%d bytes\n", bytesRead, fileSize);
    free(audioData);
    return;
  }

  // Reproducir desde buffer en RAM con buffer de 32KB para decodificación suave
  AudioFileSourcePROGMEM* memSrc = new AudioFileSourcePROGMEM(audioData, fileSize);
  buff = new AudioFileSourceBuffer(memSrc, 32768);
  mp3  = new AudioGeneratorMP3();

  if (!mp3->begin(buff, out)) {
    Serial.println("[AUDIO] Error al iniciar decodificador MP3");
    delete mp3;  mp3  = nullptr;
    delete buff; buff = nullptr;
    delete memSrc;
    free(audioData);
    return;
  }

  Serial.printf("[AUDIO] Reproduciendo %d bytes...\n", fileSize);

  // Loop de reproducción: cede CPU al scheduler entre frames
  while (mp3 && mp3->isRunning()) {
    if (!mp3->loop()) {
      mp3->stop();
      break;
    }
    vTaskDelay(pdMS_TO_TICKS(1));
  }

  Serial.println("[AUDIO] Reproducción completada");
  stopAudio();
  delete memSrc;
  free(audioData);
}

// ══════════════════════════════════════════════════════════════
//  GOOGLE CLOUD TTS
//  Obtener API Key: console.cloud.google.com
//  Activar: "Cloud Text-to-Speech API" → Credenciales → API Key
//  Coste: gratuito hasta 1M caracteres/mes
// ══════════════════════════════════════════════════════════════

bool speakCloudTTS(const String& text) {
  if (WiFi.status() != WL_CONNECTED) return false;
  if (xSemaphoreTake(wifiMutex, pdMS_TO_TICKS(5000)) != pdTRUE) return false;

  HTTPClient http;
  http.begin("https://texttospeech.googleapis.com/v1/text:synthesize?key=" +
             String(GOOGLE_TTS_KEY));
  http.addHeader("Content-Type", "application/json");
  http.setTimeout(10000);

  // Payload de síntesis
  StaticJsonDocument<512> doc;
  doc["input"]["text"]                 = text.substring(0, 200);
  doc["voice"]["languageCode"]         = "es-ES";
  doc["voice"]["name"]                 = "es-ES-Standard-A"; // Voz femenina
  doc["audioConfig"]["audioEncoding"]  = "MP3";
  doc["audioConfig"]["speakingRate"]   = 0.95;

  String body;
  serializeJson(doc, body);
  int httpCode = http.POST(body);
  bool success = false;

  if (httpCode == 200) {
    // La respuesta JSON contiene el audio codificado en base64.
    // El campo audioContent puede ocupar 50-100KB, por lo que NO usamos
    // ArduinoJson para parsear: un StaticJsonDocument pequeño lo truncaría
    // y uno grande desbordaría la RAM. En su lugar buscamos la clave
    // directamente en el String crudo del JSON.
    String payload = http.getString();
    const String key = "\"audioContent\":\"";
    int start = payload.indexOf(key);

    if (start >= 0) {
      start += key.length();
      int end = payload.indexOf("\"", start);

      if (end > start) {
        String audioBase64 = payload.substring(start, end);
        Serial.printf("[TTS] Base64 recibido: %d chars\n", audioBase64.length());

        // Decodificar base64 → bytes MP3 → guardar en LittleFS
        File audioFile = LittleFS.open("/tts_temp.mp3", "w");
        if (audioFile) {
          const char* b64      = audioBase64.c_str();
          int         len      = audioBase64.length();
          const char* b64chars =
            "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

          for (int i = 0; i < len - 3; i += 4) {
            auto idx = [&](char c) -> int {
              const char* p = strchr(b64chars, c);
              return p ? (int)(p - b64chars) : 0;
            };
            int     a  = idx(b64[i]),   b  = idx(b64[i+1]);
            int     c2 = idx(b64[i+2]), d  = idx(b64[i+3]);
            uint8_t bytes[3] = {
              (uint8_t)((a  << 2) | (b  >> 4)),
              (uint8_t)((b  << 4) | (c2 >> 2)),
              (uint8_t)((c2 << 6) |  d)
            };
            int writeLen = (b64[i+2] == '=') ? 1 : (b64[i+3] == '=') ? 2 : 3;
            audioFile.write(bytes, writeLen);
          }
          audioFile.close();

          size_t mp3size = LittleFS.open("/tts_temp.mp3", "r").size();
          Serial.printf("[TTS] MP3 guardado: %d bytes\n", mp3size);
          success = (mp3size > 0);
        }
      } else {
        Serial.println("[TTS] ERROR: no se encontró cierre de audioContent");
      }
    } else {
      Serial.println("[TTS] ERROR: campo audioContent no encontrado");
      Serial.println("[TTS] Respuesta: " + payload.substring(0, 300));
    }
  } else {
    Serial.printf("[TTS] Error HTTP %d\n", httpCode);
    Serial.println(http.getString().substring(0, 200));
  }

  http.end();
  xSemaphoreGive(wifiMutex);
  return success;
}

// Función de voz principal: TTS en la nube → fallback archivo local → log serial
void speak(const String& text) {
  Serial.println("[VOZ] " + text);

  // 1. Cloud TTS (requiere WiFi y GOOGLE_TTS_KEY configurada)
  bool ttsConfigured = strlen(GOOGLE_TTS_KEY) > 10 &&
                       String(GOOGLE_TTS_KEY) != "TU_GOOGLE_CLOUD_TTS_KEY";
  if (wifiConnected && ttsConfigured) {
    if (speakCloudTTS(text)) {
      playMP3FromLittleFS("/tts_temp.mp3");
      return;
    }
  }

  // 2. Fallback: MP3 pregrabado en LittleFS (hash de los primeros 10 chars)
  String hash = "";
  for (int i = 0; i < min((int)text.length(), 10); i++) {
    if (isAlphaNumeric(text[i])) hash += text[i];
  }
  String localPath = "/audio_" + hash + ".mp3";
  if (LittleFS.exists(localPath)) {
    playMP3FromLittleFS(localPath.c_str());
    return;
  }

  // 3. Sin audio disponible: mostrar mensaje en Serial Monitor
  Serial.println("[VOZ] Sin audio. Configura GOOGLE_TTS_KEY o añade MP3 pregrabados.");
}

// ══════════════════════════════════════════════════════════════
//  GEMINI API
// ══════════════════════════════════════════════════════════════

String askGemini(const String& context) {
  if (!wifiConnected) return "Sin conexión WiFi.";

  // Clave de caché basada en los primeros 30 caracteres alfanuméricos
  String cacheKey = "";
  for (int i = 0; i < min((int)context.length(), 30); i++) {
    if (isAlphaNumeric(context[i])) cacheKey += context[i];
  }

  if (cacheExists(cacheKey)) {
    Serial.println("[Gemini] Usando caché");
    return cacheRead(cacheKey);
  }

  if (xSemaphoreTake(wifiMutex, pdMS_TO_TICKS(8000)) != pdTRUE) {
    return "Error de acceso a red.";
  }

  HTTPClient http;
  http.begin("https://generativelanguage.googleapis.com/v1beta/models/"
             "gemini-1.5-flash:generateContent?key=" + String(GEMINI_KEY));
  http.addHeader("Content-Type", "application/json");
  http.setTimeout(12000);

  String prompt =
    "Eres un mecánico experto. Responde SOLO en español. "
    "Máximo 2 frases cortas y simples. Sin términos técnicos. "
    "Da una recomendación concreta y accionable:\n\n" + context;

  StaticJsonDocument<1024> doc;
  JsonObject content = doc.createNestedArray("contents").createNestedObject();
  content["parts"].createNestedObject()["text"] = prompt;
  JsonObject cfg = doc.createNestedObject("generationConfig");
  cfg["maxOutputTokens"] = 120;
  cfg["temperature"]     = 0.2;

  String body;
  serializeJson(doc, body);

  int    httpCode = http.POST(body);
  String response = "";

  if (httpCode == 200) {
    StaticJsonDocument<2048> res;
    if (!deserializeJson(res, http.getString())) {
      response = res["candidates"][0]["content"]["parts"][0]["text"].as<String>();
      response.trim();
      if (response.length() > 0) cacheWrite(cacheKey, response);
    }
  } else {
    Serial.printf("[Gemini] Error HTTP %d\n", httpCode);
    response = "Error al analizar. Intenta de nuevo.";
  }

  http.end();
  xSemaphoreGive(wifiMutex);
  return response;
}

// ══════════════════════════════════════════════════════════════
//  DIAGNÓSTICO PRINCIPAL
// ══════════════════════════════════════════════════════════════

DiagResult runDiagnostic() {
  DiagResult result = {-1, -1, -1, -1, -1, "Ninguno", "", false};
  Serial.println("\n══════════ DIAGNÓSTICO ══════════");

  // Leer todos los sensores vía OBD2
  result.rpm   = readRPM();
  result.speed = readSpeed();
  result.temp  = readCoolantTemp();
  result.load  = readEngineLoad();
  result.fuel  = readFuelLevel();

  String dtcs = parseDTCs(readDTCs());
  strncpy(result.dtcs, dtcs.c_str(), sizeof(result.dtcs) - 1);

  Serial.printf("[OBD] RPM:%d | Vel:%d km/h | Temp:%d°C | Carga:%d%% | Comb:%d%%\n",
                result.rpm, result.speed, result.temp, result.load, result.fuel);
  Serial.println("[OBD] DTCs: " + dtcs);

  // Alerta crítica local (sin necesitar API)
  if (result.temp > 105) {
    snprintf(result.aiResponse, sizeof(result.aiResponse),
             "Alerta crítica. Motor sobrecalentado a %d grados. Para el coche inmediatamente.",
             result.temp);
    result.hasError = true;
    return result;
  }

  String aiText = "";

  // Sin WiFi: diagnóstico básico local
  if (!wifiConnected) {
    aiText = (dtcs == "Ninguno")
      ? "Sin conexión. Sensores parecen normales. Sin códigos de error detectados."
      : "Sin conexión. Códigos de error: " + dtcs + ". Visita un taller.";
    strncpy(result.aiResponse, aiText.c_str(), sizeof(result.aiResponse) - 1);
    return result;
  }

  // Todo normal: respuesta local sin llamar a Gemini
  if (dtcs == "Ninguno" && result.rpm > 0 && result.temp > 60 && result.temp < 100) {
    aiText = "Motor en buen estado. Sin códigos de error. Todo funciona correctamente.";
    strncpy(result.aiResponse, aiText.c_str(), sizeof(result.aiResponse) - 1);
    return result;
  }

  // Situación anómala: consultar Gemini
  vTaskDelay(pdMS_TO_TICKS(100)); // Dar tiempo al BT para estabilizarse

  String context =
    "Datos del vehículo en marcha:\n"
    "- RPM: "               + (result.rpm   >= 0 ? String(result.rpm)   + " rpm"  : "N/A") + "\n"
    "- Velocidad: "         + (result.speed >= 0 ? String(result.speed) + " km/h" : "N/A") + "\n"
    "- Temperatura motor: " + (result.temp  >= 0 ? String(result.temp)  + " °C"   : "N/A") + "\n"
    "- Carga del motor: "   + (result.load  >= 0 ? String(result.load)  + "%"     : "N/A") + "\n"
    "- Combustible: "       + (result.fuel  >= 0 ? String(result.fuel)  + "%"     : "N/A") + "\n"
    "- Códigos de error: "  + dtcs;

  aiText = askGemini(context);
  strncpy(result.aiResponse, aiText.c_str(), sizeof(result.aiResponse) - 1);

  Serial.println("[IA] " + aiText);
  Serial.println("═════════════════════════════════\n");
  return result;
}

// ══════════════════════════════════════════════════════════════
//  FREERTOS — TAREA NÚCLEO 0: OBD2 + BOTÓN
//  Núcleo 0: exclusivo para Bluetooth. No hace operaciones de red.
// ══════════════════════════════════════════════════════════════

void obdTask(void* pvParameters) {
  Serial.println("[TASK0] OBD iniciada en núcleo " + String(xPortGetCoreID()));

  while (true) {
    uint8_t cmd = 0;
    if (xQueueReceive(cmdQueue, &cmd, pdMS_TO_TICKS(100)) == pdTRUE) {
      if (cmd == 1) {
        speak("Iniciando diagnóstico. Un momento.");
        DiagResult result = runDiagnostic();

        if (result.fuel >= 0 && result.fuel < 10) {
          speak("Aviso: combustible muy bajo, " + String(result.fuel) + " por ciento.");
          vTaskDelay(pdMS_TO_TICKS(500));
        }
        xQueueSend(diagQueue, &result, pdMS_TO_TICKS(1000));
      }
    }

    // Leer botón con debounce
    if (digitalRead(BUTTON_PIN) == LOW) {
      vTaskDelay(pdMS_TO_TICKS(50));
      if (digitalRead(BUTTON_PIN) == LOW) {
        uint8_t triggerCmd = 1;
        xQueueSend(cmdQueue, &triggerCmd, 0);
        while (digitalRead(BUTTON_PIN) == LOW) vTaskDelay(pdMS_TO_TICKS(10));
      }
    }

    vTaskDelay(pdMS_TO_TICKS(10));
  }
}

// ══════════════════════════════════════════════════════════════
//  FREERTOS — TAREA NÚCLEO 1: AUDIO + SERIAL CLI
//  Núcleo 1: reproducción de audio y comandos de consola.
// ══════════════════════════════════════════════════════════════

void audioTask(void* pvParameters) {
  Serial.println("[TASK1] Audio iniciada en núcleo " + String(xPortGetCoreID()));

  while (true) {
    // Reproducir respuesta de diagnóstico si hay una pendiente
    DiagResult result;
    if (xQueueReceive(diagQueue, &result, pdMS_TO_TICKS(50)) == pdTRUE) {
      speak(String(result.aiResponse));
    }

    // Comandos por Serial Monitor
    if (Serial.available()) {
      String cmd = Serial.readStringUntil('\n');
      cmd.trim();
      cmd.toLowerCase();

      if (cmd == "diag") {
        uint8_t triggerCmd = 1;
        xQueueSend(cmdQueue, &triggerCmd, 0);

      } else if (cmd == "rpm") {
        Serial.println("RPM: " + String(readRPM()));
      } else if (cmd == "temp") {
        Serial.println("Temp: " + String(readCoolantTemp()) + " °C");
      } else if (cmd == "speed") {
        Serial.println("Vel: " + String(readSpeed()) + " km/h");
      } else if (cmd == "fuel") {
        Serial.println("Comb: " + String(readFuelLevel()) + " %");
      } else if (cmd == "dtc") {
        Serial.println("DTCs: " + parseDTCs(readDTCs()));

      } else if (cmd == "vol+") {
        currentGain = min(1.0f, currentGain + 0.1f);
        if (out) out->SetGain(currentGain);
        Serial.println("[AUDIO] Ganancia: " + String(currentGain));
      } else if (cmd == "vol-") {
        currentGain = max(0.1f, currentGain - 0.1f);
        if (out) out->SetGain(currentGain);
        Serial.println("[AUDIO] Ganancia: " + String(currentGain));

      } else if (cmd.startsWith("say ")) {
        speak(cmd.substring(4));

      } else if (cmd == "cache") {
        File root = LittleFS.open("/");
        File f = root.openNextFile();
        int count = 0;
        while (f) {
          Serial.printf("  %s (%d bytes)\n", f.name(), (int)f.size());
          f = root.openNextFile();
          count++;
        }
        Serial.println("[CACHE] Total: " + String(count) + " archivos");

      } else if (cmd == "clearcache") {
        LittleFS.format();
        LittleFS.begin(true);
        Serial.println("[CACHE] Limpiada");

      } else if (cmd == "status") {
        Serial.println("[STATUS] WiFi : " + String(wifiConnected ? "OK" : "SIN CONEXIÓN"));
        Serial.println("[STATUS] BT   : " + String(btConnected   ? "OK" : "SIN CONEXIÓN"));
        Serial.printf( "[STATUS] Heap : %d bytes libres\n", ESP.getFreeHeap());
        Serial.printf( "[STATUS] PSRAM: %s\n", psramFound() ? "Disponible" : "No disponible");
        Serial.printf( "[STATUS] Core : %d\n", xPortGetCoreID());

      } else if (cmd.length() > 0) {
        // Comando AT directo al ELM327
        Serial.println("[OBD RAW] → " + sendOBD(cmd));
      }
    }

    vTaskDelay(pdMS_TO_TICKS(10));
  }
}

// ══════════════════════════════════════════════════════════════
//  SETUP
// ══════════════════════════════════════════════════════════════

void setup() {
  Serial.begin(115200);
  Serial.println("\n╔════════════════════════════════════╗");
  Serial.println("║   DACIA SMART AI ASSISTANT v3.2   ║");
  Serial.println("╚════════════════════════════════════╝");

  pinMode(BUTTON_PIN, INPUT_PULLUP);

  // ── Semáforos y colas PRIMERO ──────────────────────────────
  // CRÍTICO: deben existir antes de cualquier llamada a sendOBD()
  // o cualquier operación HTTP que use btMutex / wifiMutex.
  btMutex   = xSemaphoreCreateMutex();
  wifiMutex = xSemaphoreCreateMutex();
  diagQueue = xQueueCreate(2, sizeof(DiagResult));
  cmdQueue  = xQueueCreate(5, sizeof(uint8_t));

  if (!btMutex || !wifiMutex || !diagQueue || !cmdQueue) {
    Serial.println("[ERROR FATAL] No se pudieron crear semáforos/colas. Reiniciando...");
    ESP.restart();
  }
  Serial.println("[RTOS] Semáforos y colas OK");

  // ── LittleFS ───────────────────────────────────────────────
  if (!LittleFS.begin(true)) {
    Serial.println("[FS] Error. Formateando LittleFS...");
    LittleFS.format();
    LittleFS.begin(true);
  }
  Serial.printf("[FS] LittleFS OK — %d KB libres\n",
                (int)(LittleFS.totalBytes() - LittleFS.usedBytes()) / 1024);

  // ── Audio I2S ──────────────────────────────────────────────
  initAudio();

  // ── WiFi ───────────────────────────────────────────────────
  Serial.print("[WiFi] Conectando a " + String(WIFI_SSID) + " ");
  WiFi.begin(WIFI_SSID, WIFI_PASS);
  for (int i = 0; i < 20 && WiFi.status() != WL_CONNECTED; i++) {
    vTaskDelay(pdMS_TO_TICKS(500));
    Serial.print(".");
  }
  wifiConnected = (WiFi.status() == WL_CONNECTED);
  Serial.println(wifiConnected
    ? "\n[WiFi] Conectado → " + WiFi.localIP().toString()
    : "\n[WiFi] Sin conexión. Modo offline activado.");

  // ── Bluetooth → ELM327 ────────────────────────────────────
  BT.begin("DaciaAI_v3", true); // Modo maestro
  BT.setPin(ELM327_PIN);
  Serial.println("[BT] Buscando ELM327 (" + String(ELM327_NAME) + ")...");

  for (int i = 0; i < 5 && !btConnected; i++) {
    Serial.println("[BT] Intento " + String(i + 1) + "/5...");
    btConnected = BT.connect(ELM327_NAME);
    if (!btConnected) vTaskDelay(pdMS_TO_TICKS(2000));
  }

  if (btConnected) {
    bool elmOk = initELM327();
    Serial.println(elmOk ? "[OBD] ELM327 inicializado OK" : "[OBD] ELM327 con advertencias");
  } else {
    Serial.println("[BT] No se pudo conectar. Verifica que el ELM327 esté encendido.");
  }

  // ── Lanzar tareas FreeRTOS ─────────────────────────────────
  xTaskCreatePinnedToCore(obdTask,   "OBD_Task",   8192, NULL, 2, &obdTaskHandle,   0);
  xTaskCreatePinnedToCore(audioTask, "Audio_Task", 8192, NULL, 1, &audioTaskHandle, 1);
  Serial.println("[RTOS] Tareas lanzadas en núcleos 0 y 1");

  // ── Mensaje de bienvenida ──────────────────────────────────
  String welcome = btConnected
    ? "Dacia Smart AI v3.2 listo. Pulsa el botón para diagnosticar."
    : "Sistema v3.2 listo. Sin escáner OBD. Verifica el Bluetooth.";
  speak(welcome);

  Serial.println("[BOOT] Sistema listo\n");
}

// ══════════════════════════════════════════════════════════════
//  LOOP — Monitorización de conexiones
//  El procesamiento real ocurre en obdTask y audioTask (FreeRTOS).
// ══════════════════════════════════════════════════════════════

void loop() {
  // Reconexión WiFi cada 30 segundos si se pierde la conexión
  static unsigned long lastWifiCheck = 0;
  if (millis() - lastWifiCheck > 30000) {
    lastWifiCheck = millis();
    wifiConnected = (WiFi.status() == WL_CONNECTED);
    if (!wifiConnected) {
      Serial.println("[WiFi] Conexión perdida. Reconectando...");
      WiFi.reconnect();
    }
  }

  // Reconexión Bluetooth cada 15 segundos si se pierde la conexión
  static unsigned long lastBtCheck = 0;
  if (millis() - lastBtCheck > 15000) {
    lastBtCheck = millis();
    if (!BT.connected()) {
      btConnected = false;
      Serial.println("[BT] Conexión perdida. Reconectando al ELM327...");
      if (BT.connect(ELM327_NAME)) {
        btConnected = true;
        initELM327();
        Serial.println("[BT] Reconectado OK");
      }
    }
  }

  vTaskDelay(pdMS_TO_TICKS(1000));
}
